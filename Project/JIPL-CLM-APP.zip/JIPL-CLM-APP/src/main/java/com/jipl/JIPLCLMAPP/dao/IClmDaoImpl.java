package com.jipl.JIPLCLMAPP.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

import com.jipl.JIPLCLMAPP.model.ClaimCloseRequest;
import com.jipl.JIPLCLMAPP.model.ClaimCloseResponse;
import com.jipl.JIPLCLMAPP.model.ClmRegDetails;
import com.jipl.JIPLCLMAPP.model.ClmRegRequest;
import com.jipl.JIPLCLMAPP.model.ClmRegResponse;
import com.jipl.JIPLCLMAPP.model.DeleteMultiClaimRequest;
import com.jipl.JIPLCLMAPP.model.DeleteResponse;
import com.jipl.JIPLCLMAPP.model.DocumentUploadRequest;
import com.jipl.JIPLCLMAPP.model.DocumentUploadResponse;
import com.jipl.JIPLCLMAPP.model.SurveyAppoitmentRequest;
import com.jipl.JIPLCLMAPP.model.SurveyAppoitmentResponse;
import com.jipl.JIPLCLMAPP.model.SurveyCompletionRequest;
import com.jipl.JIPLCLMAPP.model.SurveyCompletionResponse;
import com.jipl.JIPLCLMAPP.model.UpdateRequest;
import com.jipl.JIPLCLMAPP.model.UpdateResponse;
import com.jipl.JIPLCLMAPP.utility.CommonUtils;
import com.jipl.JIPLCLMAPP.utility.DbUtility;
import com.jipl.JIPLCLMAPP.utility.GetConnection;


@Repository
public class IClmDaoImpl implements IClmDao {

@Override
public ClmRegResponse registerClaim(ClmRegRequest regRequest) {
	ClmRegResponse response = new ClmRegResponse();
	String coverNoteNo = regRequest.getCoverNoteNo();
	String customerName = regRequest.getCustomerName();
	String placeOfAccident = regRequest.getPlaceOfAccident();
	String vehicalRegNo = regRequest.getVehicalRegNo();
	String licenNo = regRequest.getLicenNo();
	String causeOfAccident = regRequest.getCauseOfAccident();
	String dateOfBith = regRequest.getDateOfBith();
	String accidentDate = regRequest.getAccidentDate();
	String driveName = regRequest.getDriveName();
	String mobileNo = regRequest.getMobileNo();
	String workshopId = regRequest.getWorkshopId();
	String workshopCity = regRequest.getWorkshopCity();
	String delearClaimId = regRequest.getDelearClaimId();
	String delearMobileNo = regRequest.getDelearMobileNo();
	String delearFlag = regRequest.getDelearFlag();
	String policyNo=null;
	String policyResult=CommonUtils.validateCoverNote(coverNoteNo,accidentDate,delearFlag.toUpperCase());
	if(policyResult==null)
	{
		response.setAck("0");
		response.setMessage("Policy/Cover Note Number does not exist, hence Claim not Registred");
		response.setClmNo("");
		response.setCoverNoteNo(coverNoteNo);
		return response;
	}
	else if(policyResult.equals("0"))
	{
		response.setAck("0");
		response.setMessage("Accident Date is not within Policy Active Period, hence Claim not Registred");
		response.setClmNo("");
		response.setCoverNoteNo(coverNoteNo);
		return response;
	}
	else
	{
			policyNo=policyResult;
	}
	int clm_status=CommonUtils.isAlreadyClaimExistOnPolicy(policyNo);
	if(clm_status==-1)
	{
		response.setAck("0");
		response.setMessage("Some error While Processing Claim registration Request,Please Contact IT Team");
		response.setClmNo("");
		response.setCoverNoteNo(coverNoteNo);
		return response;
	}
	String query="insert into JIPL_CLM_DTLS(clm_no,cover_note,vehical_reg_no,licen_no,delear_flag,reg_message,clm_status,"
				+ "clm_reg_date,dob,date_of_accident,cause_of_accident,place_of_accident,cust_name,driver_name,cust_mobileno,"
				+ "pol_no,workshop_id ,workshop_city,delear_mob_no,delear_clm_id)"
				+ "	values(?,?,?,?,?,?,?,TO_CHAR (sysdate, 'YYYY-MM-DD'),?,?,?,?,?,?,?,?,?,?,?,?)";
	Connection con=GetConnection.createConnection();
	if(con!=null)
	{
			
		try {
				if(clm_status==0)
				{
					
					String msg="Claim is already registred and not yet settled, you can't register new Claim";
					PreparedStatement ps=con.prepareStatement(query);
					ps.setInt(1, 0);
					ps.setString(2, coverNoteNo);
					ps.setString(3, vehicalRegNo);
					ps.setString(4, licenNo);
					ps.setString(5, delearFlag.toUpperCase());
					ps.setString(6, msg);
					ps.setString(7, null);// O means open Status
					ps.setString(8, dateOfBith);
					ps.setString(9, accidentDate);
					ps.setString(10, causeOfAccident);
					ps.setString(11, placeOfAccident);
					ps.setString(12, customerName);
					ps.setString(13, driveName);
					ps.setString(14, mobileNo);
					ps.setString(15, policyNo);
					ps.setString(16, workshopId);
					ps.setString(17, workshopCity);
					ps.setString(18, delearMobileNo);
					ps.setString(19, delearClaimId);
					ps.executeUpdate();
					response.setAck("0");
					response.setMessage(msg);
					response.setClmNo("");
					response.setCoverNoteNo(coverNoteNo);
			 }//clm_status==0
			if(clm_status==1)
			{
				String msg="Claim Registered Successfully";
				DbUtility dbUtility=new DbUtility();
				int clm_id=dbUtility.generateClaimNo();
				LocalDate date=LocalDate.now();
				
				String clm_number="OC-"+date.getYear()+"-"+date.getMonthValue()+"-"+clm_id;
				PreparedStatement ps=con.prepareStatement(query);
				ps.setString(1, clm_number);
				ps.setString(2, coverNoteNo);
				ps.setString(3, vehicalRegNo);
				ps.setString(4, licenNo);
				ps.setString(5, delearFlag.toUpperCase());
				ps.setString(6,msg);
				ps.setString(7, "Open");
				ps.setString(8, dateOfBith);
				ps.setString(9, accidentDate);
				ps.setString(10, causeOfAccident);
				ps.setString(11, placeOfAccident);
				ps.setString(12, customerName);
				ps.setString(13, driveName);
				ps.setString(14, mobileNo);
				ps.setString(15, policyNo);
				ps.setString(16, workshopId);
				ps.setString(17, workshopCity);
				ps.setString(18, delearMobileNo);
				ps.setString(19, delearClaimId);
				int count=ps.executeUpdate();
				if(count>0 && clm_id!=0)
				{
						response.setAck("1");
						response.setClmNo(""+clm_number);
						response.setCoverNoteNo(coverNoteNo);
						response.setMessage(msg);
				}
				else
				{
						response.setAck("0");
						response.setClmNo("");
						response.setCoverNoteNo(coverNoteNo);	
						response.setMessage("Unable to Register Please Contact IT Team !!!");
				 }
			 }//(clm_status==1)
			}//try
			catch (Exception e) {
				String msg=e.getMessage();
				response.setAck("0");
				response.setClmNo("");
				response.setCoverNoteNo(coverNoteNo);	
				response.setMessage("Exception "+msg);
			}
			
		}//(con!=null)
		else
		{
			response.setAck("0");
			response.setClmNo(null);
			response.setCoverNoteNo(coverNoteNo);	
			response.setMessage("Sorry! .. Unable to Connect Database");
		}
		return response;
}
@Override
public ClmRegDetails getSingleClmDtls(String claimno) {
	boolean validateClaim=CommonUtils.validateClaimNumber(claimno);
	ClmRegDetails regDtlresp = new ClmRegDetails();
	if(validateClaim==false)
	{
		regDtlresp.setAck("0");
		regDtlresp.setRespmessage("Claim Number Not Exist");
		return regDtlresp;
	}
	String query ="select clm_no,cover_note,cust_name,place_of_accident,vehical_reg_no,"
			+ "licen_no,cause_of_accident,dob,date_of_accident,driver_name,driver_name,"
			+ "cust_mobileno,workshop_id,workshop_city,delear_clm_id,delear_mob_no,"
			+ "delear_flag,CLM_REG_DATE,reg_message,clm_status,pol_no,survey_id,survey_app_date, "
			+ "survey_done_date from JIPL_CLM_DTLS where clm_no=?";
	Connection con = GetConnection.createConnection();
	if (con != null) {
		try {
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, claimno);
			ResultSet rs = ps.executeQuery();
			if (rs != null) {
				String clmno = null;
				while (rs.next()) {
					clmno = rs.getString("clm_no");
					regDtlresp.setClmNo(clmno);
					regDtlresp.setCoverNoteNo(rs.getString("cover_note"));
					regDtlresp.setCustomerName(rs.getString("cust_name"));
					regDtlresp.setPlaceOfAccident(rs.getString("place_of_accident"));
					regDtlresp.setVehicalRegNo(rs.getString("vehical_reg_no"));
					regDtlresp.setLicenNo(rs.getString("licen_no"));
					regDtlresp.setCauseOfAccident(rs.getString("cause_of_accident"));
					regDtlresp.setDateOfBith(rs.getString("dob"));
					regDtlresp.setAccidentDate(rs.getString("date_of_accident"));
					regDtlresp.setDriveName(rs.getString("driver_name"));
					regDtlresp.setMobileNo(rs.getString("cust_mobileno"));
					regDtlresp.setWorkshopId(rs.getString("workshop_id"));
					regDtlresp.setWorkshopCity(rs.getString("workshop_city"));
					regDtlresp.setDelearClaimId(rs.getString("delear_clm_id"));
					regDtlresp.setDelearMobileNo(rs.getString("delear_mob_no"));
					regDtlresp.setDelearFlag(rs.getString("delear_flag"));
					regDtlresp.setRegDate(rs.getString("CLM_REG_DATE"));
					regDtlresp.setMessage(rs.getString("reg_message"));
					regDtlresp.setClmStatus(rs.getString("clm_status"));
					regDtlresp.setAck("1");
					regDtlresp.setRespmessage("Data Available");
					regDtlresp.setPolicyNo(rs.getString("pol_no"));
				}
				if (clmno == null) {
					regDtlresp.setAck("0");
					regDtlresp.setRespmessage("Claim Number Not Exist");
				}
			} else {
				regDtlresp.setAck("0");
				regDtlresp.setRespmessage("Some Error,Please Contact IT Team");
			}
		} catch (Exception e) {
			e.printStackTrace();
			regDtlresp.setAck("0");
			regDtlresp.setRespmessage("Some Error,Please Contact IT Team");
		}
	} else {
		regDtlresp.setAck("0");
		regDtlresp.setRespmessage("DB Connection Failed, Contact IT Team");
	}
	return regDtlresp;
}

	@Override
	public DeleteResponse deleteSingleClmDtls(String clmno) {
		DeleteResponse response=new DeleteResponse();
		String query="delete from JIPL_CLM_DTLS where clm_no=?";
		Connection con=GetConnection.createConnection();
		if(con!=null)
		{
			try {
				PreparedStatement ps=con.prepareStatement(query);
				ps.setString(1, clmno);
				int cnt=ps.executeUpdate();
				if(cnt>0)
				{
					response.setAck("1");
					response.setClmNo(clmno);
					response.setMessage("Claim is deleted Successfully");
				}
				else
				{
					response.setAck("0");
					response.setClmNo(clmno);
					response.setMessage("Claim number does not exist");
					
				}
			}
			catch (Exception e) {
				response.setAck("0");
				response.setClmNo(clmno);
				response.setMessage("Exception while deleting "+e.getMessage());
				
			}
		}
		else
		{
			response.setAck("0");
			response.setClmNo(clmno);
			response.setMessage("Connection Error, Please contanct IT Team");
		}
		return response;
		
}

	@Override
	public List<DeleteResponse> deleteMultiClmDtls(List<DeleteMultiClaimRequest> listRequest) {
		String query="delete from JIPL_CLM_DTLS where clm_no=? and delear_flag=?";
		List<DeleteResponse> listResponse=new ArrayList<DeleteResponse>();
		DeleteResponse del=null;
		Connection con=GetConnection.createConnection();
		if(con!=null)
		{
			try {
				PreparedStatement ps=con.prepareStatement(query);
				for(DeleteMultiClaimRequest req:listRequest)
				{
					
					ps.setString(1, req.getClaimNo());
					ps.setString(2, req.getDelearFlag().toUpperCase());
					int cnt=ps.executeUpdate();
					if(cnt>0)
					{
						del=new DeleteResponse();
						del.setAck("1");
						del.setClmNo(req.getClaimNo());
						del.setMessage("Claim Details Deleted Successfully");
						listResponse.add(del);
					}
					else
					{
						del=new DeleteResponse();
						del.setAck("0");
						del.setClmNo(req.getClaimNo());
						del.setMessage("Claim number not exist");
						listResponse.add(del);
						
					}
				}
			}
			catch (Exception e) {
				del=new DeleteResponse();
				del.setAck("0");
				del.setClmNo("");
				del.setMessage("Exception "+e.getMessage());
				listResponse.add(del);
				
			}
		}
		else
		{
			del=new DeleteResponse();
			del.setAck("0");
			del.setClmNo("");
			del.setMessage("Unable to Connect DB");
			listResponse.add(del);
			
		}
		return listResponse;
	}
	@Override
	public UpdateResponse updateSingleClmDtls(UpdateRequest request) {
     String query="update JIPL_CLM_DTLS set cust_mobileno=?,"
     		+ " delear_mob_no=? where clm_no=? and delear_flag=?";
     UpdateResponse response=new UpdateResponse();
     Connection con=GetConnection.createConnection();
     String clmno=request.getClmno();
     String delearFlag=request.getDelearFlag();
     String custMobileNo=request.getCustMobileNo();
     String delelearMobileNo=request.getDelearMobileNo();
     
     if(con!=null)
     {
    	 try{
    		 PreparedStatement ps=con.prepareStatement(query);
    		 ps.setString(1, custMobileNo);
    		 ps.setString(2, delelearMobileNo);
    		 ps.setString(3, clmno);
    		 ps.setString(4, delearFlag);
    		 int rowCount=ps.executeUpdate();
    		 if(rowCount>0)
    		 {
    			 response.setAck("1");
    	    	 response.setClmno(clmno);
    	    	 response.setMessage("Updated SuccessFully");
    		 }
    		 else
    		 {
    			 response.setAck("0");
    	    	 response.setClmno(clmno);
    	    	 response.setMessage("Unable to Update Details,Please Contact IT Team");
    		 }
    	 }
    	 catch (Exception e) {
    		 response.setAck("0");
        	 response.setClmno(clmno);
        	 response.setMessage("Excpetion "+e.getMessage());
		}
     }
     else
     {
    	 response.setAck("0");
    	 response.setClmno(clmno);
    	 response.setMessage("Connection Error,Please Contact IT Team");
     }
	 return response;
	}
	public SurveyAppoitmentResponse appointSurveyor(SurveyAppoitmentRequest request)
	{
		String UpdateQuery="update JIPL_CLM_DTLS set clm_status=?,SURVEY_ID=?,"
	     		+ "SURVEY_APP_DATE=TO_Char(sysdate,'YYYY-MM-DD'),REG_MESSAGE=? where clm_no=?";
		String msg="Surveyor Appointed Successfully !";
		SurveyAppoitmentResponse response=new SurveyAppoitmentResponse();
		Connection con=GetConnection.createConnection();
		if(con!=null)
		{
				try 
				{
					PreparedStatement ps=con.prepareStatement(UpdateQuery);
					ps.setString(1,"SA");
					ps.setString(2,request.getSurveyorId());
					ps.setString(3,msg);
					ps.setString(4, request.getClaimId());
					int cnt=ps.executeUpdate();
					if(cnt>0)
					{
					
						response.setAck("1");
						response.setClmNo(request.getClaimId());					
						response.setMessage("Surveyor Appointed Successfully !!!");
						
					}
					else
					{
						response.setAck("0");
						response.setClmNo(request.getClaimId());	
						response.setMessage("Unable to Process Please Contact IT Team !!!");
					}
				}
				catch (Exception e) {
					e.printStackTrace();
					response.setAck("0");
					response.setClmNo(request.getClaimId());
					response.setMessage("Exception "+e.getMessage());
				}
			}
			else
			{
				response.setAck("0");
				response.setClmNo(request.getClaimId());
				response.setMessage("Connection Error,Please contact IT Team");
			}
		return response;
	}
	public SurveyCompletionResponse surveyComplete(SurveyCompletionRequest request)
	{
		String UpdateStatus="update JIPL_CLM_DTLS set clm_status=?,survey_compl_remark=?,"
	     		+ "survey_done_date=TO_Char(sysdate,'YYYY-MM-DD') where clm_no=? and survey_id=?";
		String msg="Surveyor Completion Done Successfully !!!";    
		SurveyCompletionResponse response=new SurveyCompletionResponse();
			Connection con=GetConnection.createConnection();
			if(con!=null)
			{
				try 
				{
					
					PreparedStatement ps=con.prepareStatement(UpdateStatus);
					ps=con.prepareStatement(UpdateStatus);
					ps.setString(1,"SC");
					ps.setString(2, request.getRemark());
					ps.setString(3, request.getClaimId());
					ps.setString(4, request.getSurveyorId());
					int cnt=ps.executeUpdate();
					if(cnt>0)
					{
						response.setAck("1");
						response.setClmNo(request.getClaimId());					
						response.setMessage(msg);
					}
					else
					{
						response.setAck("0");
						response.setClmNo(request.getClaimId());					
						response.setMessage("Unable to Process Survey Completion!!!");
					}
				}
				catch (Exception e) {
					e.printStackTrace();
					response.setAck("0");
					response.setClmNo(request.getClaimId());
					response.setMessage("Exception "+e.getMessage());
				}
			}
			else
			{
				response.setAck("0");
				response.setClmNo(request.getClaimId());
				response.setMessage("Connection Error, Please contact IT Team");
			}
		return response;
	}
	public DocumentUploadResponse uplodDocument(DocumentUploadRequest request)
	{
		DocumentUploadResponse response=new DocumentUploadResponse();
		String vclmno=request.getClaimNumber();
		String vDocName=request.getDocName();
		String vDocData=request.getDocData();
		String vDocExt=request.getDocExtention();
		String classType="MOTOR_CLAIM";
		String query="insert into JIPL_DOC_DTLS(doc_id,clm_no,doc_type,class_type,doc_path,"
				+ "doc_name,entry_date)"
					+ "values(?,?,?,?,?,?,sysdate)";
		String docId=CommonUtils.getDocId();
		String docPath=CommonUtils.converIntoPdf(vclmno, vDocName, vDocData);
			if(docId!=null&&docPath!=null)
			{
				Connection con=GetConnection.createConnection();
				if(con!=null)
				{
					try 
					{
						PreparedStatement ps=con.prepareStatement(query);
						ps.setString(1, docId);
						ps.setString(2, vclmno);
						ps.setString(3, vDocExt);
						ps.setString(4, classType);
						ps.setString(5, docPath);
						ps.setString(6, vDocName);
						int count=ps.executeUpdate();
						if(count>0)
						{
							String UpdateStatus="update JIPL_CLM_DTLS set clm_status=?,"
						     		+ "doc_id=?,REG_MESSAGE=? where clm_no=?";
							ps=con.prepareStatement(UpdateStatus);
							ps.setString(1,"DU");
							ps.setString(2,docId);
							ps.setString(3, "Document Uploaded "+vDocName);
							ps.setString(4, vclmno);
							int cnt=ps.executeUpdate();
							if(cnt>0)
							{
								response.setAck("1");
								response.setClmno(vclmno);				
								response.setMessage(vDocName+" Document Uploaded Successfully !!!");
								
							}
							else
							{
								response.setAck("0");
								response.setClmno(vclmno);				
								response.setMessage("Document Uploaded On Server But Unable update Status of Claim!!!");
							}
						}
						else
						{
							response.setAck("0");
							response.setClmno(vclmno);	
							response.setMessage("Document Uploaded On Server But Unable insert DB entry!!!");
						}
					}
					catch (Exception e) {
						e.printStackTrace();
						response.setAck("0");
						response.setClmno(vclmno);
						response.setMessage("Exception "+e.getMessage());
					}
				}
				else
				{
					response.setAck("0");
					response.setClmno(vclmno);
					response.setMessage("Unable to Connect DB Please contact IT Team");
				}
			}
			else
			{
				response.setAck("0");
				response.setClmno(vclmno);
				response.setMessage("Please provide Valid Claim Number");
				
			}
			return response;
	}
	public ClaimCloseResponse closeClaim(ClaimCloseRequest request)
	{
		ClaimCloseResponse response=new ClaimCloseResponse();
		String Updatequery="update JIPL_CLM_DTLS set clm_status=?,reg_message=? where clm_no=?";
		String clmNo=request.getClaimNo();
		String clmStatus=CommonUtils.getClaimStatusFromClaimNuber(clmNo);
		if(clmStatus.equalsIgnoreCase("Closed"))
		{
			response.setAck("0");
			response.setClmNo(clmNo);
			response.setMessage("Claim is already Closed");
		}
		else
		{
			Connection con=GetConnection.createConnection();
			if(con!=null)
			{
				   try 
					{
							PreparedStatement ps=con.prepareStatement(Updatequery);
							ps.setString(1, "Closed");
							ps.setString(2,request.getClosingRemark());
							ps.setString(3, request.getClaimNo());
							int cnt=ps.executeUpdate();
							if(cnt>0)
							{
									response.setAck("1");
									response.setClmNo(request.getClaimNo());					
									response.setMessage("Claim Closed Successfully!!!");
							}
							else
							{
									response.setAck("0");
									response.setClmNo(request.getClaimNo());					
									response.setMessage("Unable to Close Claim!!!");
							}
						}
						catch (Exception e) {
							e.printStackTrace();
							response.setAck("0");
							response.setClmNo(request.getClaimNo());
							response.setMessage("Exception "+e.getMessage());
						}
					}
					else
					{
						response.setAck("0");
						response.setClmNo(request.getClaimNo());
						response.setMessage("Unable to Connect DB Please contact IT Team");
					}
		}
		return response;
	}
}
