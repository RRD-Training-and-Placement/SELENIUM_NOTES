package com.jipl.JIPLCLMAPP.model;

import org.springframework.stereotype.Component;

@Component
public class ClmRegRequest {

	private String coverNoteNo;
	private String customerName;
	private String placeOfAccident;
	private String vehicalRegNo;
	private String licenNo;
	private String causeOfAccident;
	private String dateOfBith;
	private String accidentDate;
	private String driveName;
	private String mobileNo;
	private String workshopId;
	private String workshopCity;
	private String delearClaimId;
	private String delearMobileNo;
	private String delearFlag;
	public String getCoverNoteNo() {
		return coverNoteNo;
	}
	public void setCoverNoteNo(String coverNoteNo) {
		this.coverNoteNo = coverNoteNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPlaceOfAccident() {
		return placeOfAccident;
	}
	public void setPlaceOfAccident(String placeOfAccident) {
		this.placeOfAccident = placeOfAccident;
	}
	public String getVehicalRegNo() {
		return vehicalRegNo;
	}
	public void setVehicalRegNo(String vehicalRegNo) {
		this.vehicalRegNo = vehicalRegNo;
	}
	public String getLicenNo() {
		return licenNo;
	}
	public void setLicenNo(String licenNo) {
		this.licenNo = licenNo;
	}
	public String getCauseOfAccident() {
		return causeOfAccident;
	}
	public void setCauseOfAccident(String causeOfAccident) {
		this.causeOfAccident = causeOfAccident;
	}
	public String getDateOfBith() {
		return dateOfBith;
	}
	public void setDateOfBith(String dateOfBith) {
		this.dateOfBith = dateOfBith;
	}
	public String getAccidentDate() {
		return accidentDate;
	}
	public void setAccidentDate(String accidentDate) {
		this.accidentDate = accidentDate;
	}
	public String getDriveName() {
		return driveName;
	}
	public void setDriveName(String driveName) {
		this.driveName = driveName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getWorkshopId() {
		return workshopId;
	}
	public void setWorkshopId(String workshopId) {
		this.workshopId = workshopId;
	}
	public String getWorkshopCity() {
		return workshopCity;
	}
	public void setWorkshopCity(String workshopCity) {
		this.workshopCity = workshopCity;
	}
	public String getDelearClaimId() {
		return delearClaimId;
	}
	public void setDelearClaimId(String delearClaimId) {
		this.delearClaimId = delearClaimId;
	}
	public String getDelearMobileNo() {
		return delearMobileNo;
	}
	public void setDelearMobileNo(String delearMobileNo) {
		this.delearMobileNo = delearMobileNo;
	}
	public String getDelearFlag() {
		return delearFlag;
	}
	public void setDelearFlag(String delearFlag) {
		this.delearFlag = delearFlag;
	}
}
