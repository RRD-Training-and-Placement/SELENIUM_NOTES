package com.jipl.JIPLCLMAPP.model;

import org.springframework.stereotype.Component;

@Component
public class UpdateRequest {
	private String clmno;
	private String delearFlag;
	private String custMobileNo;
	private String delearMobileNo;
	public String getClmno() {
		return clmno;
	}
	public void setClmno(String clmno) {
		this.clmno = clmno;
	}
	public String getDelearFlag() {
		return delearFlag;
	}
	public void setDelearFlag(String delearFlag) {
		this.delearFlag = delearFlag;
	}
	public String getCustMobileNo() {
		return custMobileNo;
	}
	public void setCustMobileNo(String custMobileNo) {
		this.custMobileNo = custMobileNo;
	}
	public String getDelearMobileNo() {
		return delearMobileNo;
	}
	public void setDelearMobileNo(String delearMobileNo) {
		this.delearMobileNo = delearMobileNo;
	}
}
