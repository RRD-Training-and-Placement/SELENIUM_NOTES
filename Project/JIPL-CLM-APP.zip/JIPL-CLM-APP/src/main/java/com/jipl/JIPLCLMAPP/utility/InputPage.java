package com.jipl.JIPLCLMAPP.utility;

public abstract class InputPage {
	public abstract void takeInput();
	public abstract void takeInputForDeleteClaim();
	public abstract void takeInputToDeleteMultiClaim();
	public abstract void takeInputToUpdateMultiClaim();
	public abstract void takeInputToDisplayCmlDetails();
	public abstract void takeInputToDispalyMultipleClmDetails();
}
