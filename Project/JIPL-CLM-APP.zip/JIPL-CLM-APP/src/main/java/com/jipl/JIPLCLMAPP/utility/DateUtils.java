package com.jipl.JIPLCLMAPP.utility;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils 
{
      public static boolean isValidateDateFormat(String inputDate,String dateFormat)
      {
    	       
    	        if(inputDate!=null && dateFormat!=null)
    	        {
    	        	DateFormat df=new SimpleDateFormat(dateFormat);
    	        	df.setLenient(false);
    	        	try
    	        	{
    	        		df.parse(inputDate);
    	        	}
    	        	catch (ParseException e) 
    	        	{
						return false;
					}
    	        	catch (Exception e) 
    	        	{
						return false;
					}
    	        }
    	        else
    	        {
    	        	return false;
    	        }
    	        return true;
}

// This method will compaire two dates 
public static boolean isFutureDate(String accDate,String dateFormat)
{
       boolean dateFalg=false;
	   try
	   {
		   SimpleDateFormat df =new SimpleDateFormat(dateFormat);
		   Date today=new Date();// java.util.Date
		   Date inpuDate=df.parse(accDate);
		   if(inpuDate.after(today))
		   {
			   dateFalg=true;
		   }
	   }
	   catch (Exception e) 
	   {
		   dateFalg= true;
	   }
       return dateFalg;
}
      
      
      
      
      
      
      
      
      
      
      
      
      
}
