package com.jipl.JIPLCLMAPP.utility;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DbUtility 
{
        
	   public int generateClaimNo()
       {
    	   Connection con=GetConnection.createConnection();
    	   int clm_no=0;
		   if(con!=null)
		   {
			   String query="select clm_no_seq.nextval from dual";// dual is dummy table
			   try
			   {
				   PreparedStatement ps=con.prepareStatement(query);
				   ResultSet rs=ps.executeQuery();
				   if(rs.next())
				   {
					   clm_no=rs.getInt(1);
				   }
			   }
			   catch (Exception e) 
			   {
				  e.printStackTrace();
				  clm_no=0; 
			  }
		   }
		   else
		   {
			   clm_no=0;
		   }
		   
    	   return clm_no;
       }

}
