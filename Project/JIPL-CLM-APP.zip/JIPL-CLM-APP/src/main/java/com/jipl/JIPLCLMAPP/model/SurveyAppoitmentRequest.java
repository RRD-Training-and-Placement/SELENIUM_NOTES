package com.jipl.JIPLCLMAPP.model;

import org.springframework.stereotype.Component;

@Component
public class SurveyAppoitmentRequest {
	private String surveyorId;//This field value is auto populated
	private String surveyorName;
	private String claimId;
	public String getSurveyorId() {
		return surveyorId;
	}
	public void setSurveyorId(String surveyorId) {
		this.surveyorId = surveyorId;
	}
	public String getSurveyorName() {
		return surveyorName;
	}
	public void setSurveyorName(String surveyorName) {
		this.surveyorName = surveyorName;
	}
	public String getClaimId() {
		return claimId;
	}
	public void setClaimId(String claimId) {
		this.claimId = claimId;
	}
	

}
