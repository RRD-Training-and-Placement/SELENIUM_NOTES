package com.jipl.JIPLCLMAPP.model;

import org.springframework.stereotype.Component;

@Component
public class SurveyAppoitmentResponse {
	private String ack;
	private String message;
	private String clmNo;
	public String getAck() {
		return ack;
	}
	public void setAck(String ack) {
		this.ack = ack;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getClmNo() {
		return clmNo;
	}
	public void setClmNo(String clmNo) {
		this.clmNo = clmNo;
	}
	

}
