package com.jipl.JIPLCLMAPP.service;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

import com.jipl.JIPLCLMAPP.model.ClaimCloseRequest;
import com.jipl.JIPLCLMAPP.model.ClaimCloseResponse;
import com.jipl.JIPLCLMAPP.model.ClmRegDetails;
import com.jipl.JIPLCLMAPP.model.ClmRegRequest;
import com.jipl.JIPLCLMAPP.model.ClmRegResponse;
import com.jipl.JIPLCLMAPP.model.DeleteMultiClaimRequest;
import com.jipl.JIPLCLMAPP.model.DeleteResponse;
import com.jipl.JIPLCLMAPP.model.DocumentUploadRequest;
import com.jipl.JIPLCLMAPP.model.DocumentUploadResponse;
import com.jipl.JIPLCLMAPP.model.SurveyAppoitmentRequest;
import com.jipl.JIPLCLMAPP.model.SurveyAppoitmentResponse;
import com.jipl.JIPLCLMAPP.model.SurveyCompletionRequest;
import com.jipl.JIPLCLMAPP.model.SurveyCompletionResponse;
import com.jipl.JIPLCLMAPP.model.UpdateRequest;
import com.jipl.JIPLCLMAPP.model.UpdateResponse;

public interface IClmService {
	public ClmRegDetails getSingleClmDtls(String clmNo);
	public ClmRegResponse registerClaim(ClmRegRequest regRequest);
	public DeleteResponse deleteSingleClmDtls(String Clmno);
	public List<DeleteResponse> deleteMultiClmDtls(List<DeleteMultiClaimRequest> request);
	public UpdateResponse updateSingleClmDtls(UpdateRequest request);
	public SurveyAppoitmentResponse appointSurveyor(SurveyAppoitmentRequest request);
	public SurveyCompletionResponse surveyComplete(SurveyCompletionRequest request);
	public DocumentUploadResponse uplodDocument(DocumentUploadRequest request);
	public ClaimCloseResponse closeClaim(ClaimCloseRequest request);
}
