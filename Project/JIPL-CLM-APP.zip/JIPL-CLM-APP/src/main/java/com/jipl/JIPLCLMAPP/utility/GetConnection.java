package com.jipl.JIPLCLMAPP.utility;

import java.sql.Connection;
import java.sql.DriverManager;

public class GetConnection 
{
	    private static Connection con=null;
	    public static Connection createConnection()
	    {
	    	try
	        {
	        	 // 1: load a driver class   
	    		Class.forName("oracle.jdbc.driver.OracleDriver");
	    		//2. Create a Connection 
	           con= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","tiger");
	        }
	        catch(Exception e)
	        {
	        	System.out.println("Excpetion in GetConnection class: "+e.toString());
	        }
	    	finally 
	    	{
				
	    	}
	    	return con;
	    }
}
