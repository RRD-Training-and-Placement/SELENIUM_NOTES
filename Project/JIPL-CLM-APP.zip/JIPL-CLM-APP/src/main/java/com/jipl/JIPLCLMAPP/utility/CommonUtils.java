package com.jipl.JIPLCLMAPP.utility;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.util.Base64Utils;
public class CommonUtils {
	
	
	public static boolean  validateMobileNumber(String mobileNo)
	{
		boolean result=false;
		try {
			Long.valueOf(mobileNo);
			result=true;
		}
		catch (Exception e) {
			result=false;
		}
		return result;
	}
    public static boolean isFutureDate(String dateInput)
    {
    	try {
    		LocalDate localDate = LocalDate.now(ZoneId.systemDefault());
    		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    		LocalDate inputDate = LocalDate.parse(dateInput, dtf);
    		return inputDate.isAfter(localDate);
    	}
    	catch (Exception e) {
			return false;
		}
    	
    }
    public static boolean validateDateFormate(String inputDate)
    {
       DateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
       sdf.setLenient(false);
       try {
           sdf.parse(inputDate);
       } catch (ParseException e) {
           return false;
       }
       return true;
    	
    }
    public static boolean validateRegistrationNumber(String vehicalRegNo)
    {
        String regex= "^[A-Z]{2}[ -][0-9]{1,2}(?: [A-Z])?(?: [A-Z]*)? [0-9]{4}$";
        return Pattern.compile(regex).matcher(vehicalRegNo).matches();

    }
    public static boolean validateLicenNumber(String licenNumber)
    {
    	String regex = "^(([A-Z]{2}[0-9]{2})( )|([A-Z]{2}-[0-9]{2}))((19|20)[0-9][0-9])[0-9]{7}$";
    	return Pattern.compile(regex).matcher(licenNumber).matches();
    }
    /*This method check given claim number is exist in the table or not*/
    public static boolean validateClaimNumber(String inputClaimNo)
    {
    	Connection con=GetConnection.createConnection();
    	String query="select clm_no  from JIPL_CLM_DTLS where clm_no=?";
    	boolean result=false;
    	if(con!=null)
		{
			try {
				PreparedStatement ps = con.prepareStatement(query);
				ps.setString(1, inputClaimNo);
				ResultSet rs = ps.executeQuery();
				if (rs != null) 
				{
					String dbclmno = null;
					while (rs.next()) 
					{
						dbclmno = rs.getString("clm_no");
					}
					if (dbclmno!=null)
					{
						result=true;
					}
			     }
			}
			catch (Exception e) {
				e.printStackTrace();
				result=false;
			}
		}
		return result;
    }
    public static boolean validateDelearFlag(String delearFlag)
    {
    	boolean result=false;
    	String dFlag[]=new String []{"HONDA","HYUNDAI","FORD","MARUTI"};
    	for(String flag:dFlag)
    	{
    		if(flag.equalsIgnoreCase(delearFlag))
    		{
    			result=true;
    			break;
    		}
    	}
    	return result;
    }
    /*This method is for check given Policy is exist in the table or not*/
    public static boolean validatePolicyNumber(String inputPolNo)
    {
    	Connection con=GetConnection.createConnection();
    	String query="select pol_no  from JIPL_POL_DTLS where pol_no=?";
    	boolean result=false;
    	if(con!=null)
		{
			try {
				PreparedStatement ps = con.prepareStatement(query);
				ps.setString(1, inputPolNo);
				ResultSet rs = ps.executeQuery();
				if (rs != null) 
				{
					String dbPolNo = null;
					while (rs.next()) 
					{
						dbPolNo = rs.getString("pol_no");
					}
					if (dbPolNo!=null)
					{
						result=true;
					}
			     }
			}
			catch (Exception e) {
				
				result=false;
			}
		}
		else
		{
			result=false;
			
		}
		return result;
    }
public static String validateCoverNote(String coverNote,String accDate)
{
	Connection con=GetConnection.createConnection();
	String query="select POL_NO,START_DATE,END_DATE from JIPL_POL_DTLS where cover_note=?";
	String polNo=null;
	String startDate=null;
	String endDate=null;
	String result=null;
	if(con!=null)
	{
		try {
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, coverNote);
			ResultSet rs = ps.executeQuery();
			if (rs != null) 
			{
				
				while (rs.next()) 
				{
					polNo = rs.getString("pol_no");
					startDate = rs.getString("START_DATE");
					endDate = rs.getString("END_DATE");
					
				}
				if (polNo!=null)
				{
					SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
			        Date date1 = sdf.parse(startDate);
			        Date date2 = sdf.parse(endDate);
			        Date input=  sdf.parse(accDate);
			        int result1=input.compareTo(date1);
			        int  result2=input.compareTo(date2);
			        
			        System.out.println(result1);
			        System.out.println(result2);
			        if(result1==0||result2==0)
			        {
			        	result=polNo;
			        }
			        else if(result1>0 && result2<0)
			        {
			        	result=polNo;
			        }
			        else
			        {
			        	//Accident Date is not within Policy Active Period
			        	result="0";
			        }
				}
		     }
		}
		catch (Exception e) {
			// if Policy not exist
			result=null;
		}
	}
	return result;
}
public static boolean  validateWorkshpId(String workshopID,String workShopcity)
{
	Connection con=GetConnection.createConnection();
	String query="select workshop_name  from JIPL_WORKSHOP_DTLS where workshop_id=?";
	boolean result=false;
	if(con!=null)
	{
		try {
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, workshopID);
			ResultSet rs = ps.executeQuery();
			if (rs != null) 
			{
				String dbWorkshopName = null;
				while (rs.next()) 
				{
					dbWorkshopName = rs.getString("workshop_name");
				}
				if (dbWorkshopName!=null)
				{
					result=true;
				}
		     }
		}
		catch (Exception e) {
			
			result=false;
		}
	}
	return result;
}
public static boolean validateDocExtention(String docExt)
{
	if(docExt.equalsIgnoreCase("pdf"))
	{
		return true;
	}
	else
	{
		return false;
	}
}
public static int isAlreadyClaimExistOnPolicy(String policyNo)
{
	String Selectquery="select clm_status From JIPL_CLM_DTLS where clm_no=(select max(clm_no) as clm_no  from JIPL_CLM_DTLS  \r\n"
			+ "where POL_NO =? group by pol_no)";
	String clmStatus=null;
	int result=0; // 0 means open and 1 means closed
	Connection con=GetConnection.createConnection();
	if(con!=null)
	{
		try 
		{
				PreparedStatement ps=con.prepareStatement(Selectquery);
				ps.setString(1, policyNo);
				ResultSet rs = ps.executeQuery();
				if (rs != null)
				{
					
					while (rs.next()) 
					{
						clmStatus = rs.getString("clm_status");
					}
					if(clmStatus.contains("C") || clmStatus==null)
					{
						result=1;
					}
					
				}
		}
		catch (Exception e) 
		{
			result=-1;
		}
	}
	return result;
}
public static String getClaimStatusFromClaimNuber(String clmNo)
{
	String Selectquery="select clm_status From JIPL_CLM_DTLS where clm_no=?";
	String clmStatus=null;
	Connection con=GetConnection.createConnection();
	if(con!=null)
	{
		try 
		{
				PreparedStatement ps=con.prepareStatement(Selectquery);
				ps.setString(1, clmNo);
				ResultSet rs = ps.executeQuery();
				if (rs != null)
				{
					
					while (rs.next()) 
					{
						clmStatus = rs.getString("clm_status");
					}
				}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	return clmStatus;
}
public static String converIntoPdf(String clmno,String DocName,String DocData)
{
	String parentFolderPath="E:/ClaimDocs";
	File parentFolder = new File(parentFolderPath);
	String childFolderPath=parentFolderPath+"/"+clmno;
	File childFolder=new File(childFolderPath);
	String resultPath=null;
	LocalDateTime time=LocalDateTime.now();
	int second=time.getSecond();
	if(parentFolder.exists()==false)
	{
		parentFolder.mkdir();
	}
	if(!parentFolder.exists()==false)
	{
		childFolder.mkdir();
	}
	if(parentFolder.exists() &&childFolder.exists())
	{
			try {
				String OUT_FILE=childFolderPath+"/"+clmno+"_"+second+"_"+DocName+".pdf";
				FileOutputStream fos = new FileOutputStream(OUT_FILE);
			    byte[] b=Base64Utils.decodeFromString(DocData);
				fos.write(b);
				fos.flush();
				fos.close();
				resultPath=OUT_FILE;
				
			 }
			catch (Exception e) {
				e.printStackTrace();
				resultPath=null;
			}
			
	}
	else
	{
		resultPath=null;
	}
	return resultPath;
}
public static boolean isTodayDate(String inputdate)
{
	
    LocalDate localDate = LocalDate.now(ZoneId.systemDefault());
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	LocalDate inputDate = LocalDate.parse(inputdate, dtf);
	return inputDate.isAfter(localDate);
   
}
public static String getDocId()
{
    	   Integer docId=null;
		   Connection con=GetConnection.createConnection();
		   if(con!=null)
		   {
			   String query="select doc_id_seq.nextval from dual";// dual is dummy table
			   try
			   {
				   PreparedStatement ps=con.prepareStatement(query);
				   ResultSet rs=ps.executeQuery();
				   if(rs.next())
				   {
					   docId=rs.getInt(1);
				   }
			   }
			   catch (Exception e) 
			   {
				  e.printStackTrace();
				  docId=0; 
			  }
		   }
		   else
		   {
			   docId=0;
		   }
		   
    	   return docId.toString();
       }
}
