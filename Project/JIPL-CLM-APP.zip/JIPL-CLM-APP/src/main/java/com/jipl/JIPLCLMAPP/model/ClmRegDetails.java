package com.jipl.JIPLCLMAPP.model;

import org.springframework.stereotype.Component;

@Component
public class ClmRegDetails {
	private String coverNoteNo;
	private String clmNo;
	private String policyNo;
	private String customerName;
	private String placeOfAccident;
	private String vehicalRegNo;
	private String licenNo;
	private String causeOfAccident;
	private String dateOfBith;
	private String accidentDate;
	private String driveName;
	private String mobileNo;
	private String workshopId;
	private String workshopCity;
	private String delearClaimId;
	private String delearMobileNo;
	private String delearFlag;
	private String regDate;
	private String message;
	private String clmStatus;
	private String ack;
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getClmNo() {
		return clmNo;
	}
	public void setClmNo(String clmNo) {
		this.clmNo = clmNo;
	}
	public String getAck() {
		return ack;
	}
	public void setAck(String ack) {
		this.ack = ack;
	}
	public String getRespmessage() {
		return respmessage;
	}
	public void setRespmessage(String respmessage) {
		this.respmessage = respmessage;
	}
	private String respmessage;
	public String getCoverNoteNo() {
		return coverNoteNo;
	}
	public void setCoverNoteNo(String coverNoteNo) {
		this.coverNoteNo = coverNoteNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPlaceOfAccident() {
		return placeOfAccident;
	}
	public void setPlaceOfAccident(String placeOfAccident) {
		this.placeOfAccident = placeOfAccident;
	}
	public String getVehicalRegNo() {
		return vehicalRegNo;
	}
	public void setVehicalRegNo(String vehicalRegNo) {
		this.vehicalRegNo = vehicalRegNo;
	}
	public String getLicenNo() {
		return licenNo;
	}
	public void setLicenNo(String licenNo) {
		this.licenNo = licenNo;
	}
	public String getCauseOfAccident() {
		return causeOfAccident;
	}
	public void setCauseOfAccident(String causeOfAccident) {
		this.causeOfAccident = causeOfAccident;
	}
	public String getDateOfBith() {
		return dateOfBith;
	}
	public void setDateOfBith(String dateOfBith) {
		this.dateOfBith = dateOfBith;
	}
	public String getAccidentDate() {
		return accidentDate;
	}
	public void setAccidentDate(String accidentDate) {
		this.accidentDate = accidentDate;
	}
	public String getDriveName() {
		return driveName;
	}
	public void setDriveName(String driveName) {
		this.driveName = driveName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getWorkshopId() {
		return workshopId;
	}
	public void setWorkshopId(String workshopId) {
		this.workshopId = workshopId;
	}
	public String getWorkshopCity() {
		return workshopCity;
	}
	public void setWorkshopCity(String workshopCity) {
		this.workshopCity = workshopCity;
	}
	public String getDelearClaimId() {
		return delearClaimId;
	}
	public void setDelearClaimId(String delearClaimId) {
		this.delearClaimId = delearClaimId;
	}
	public String getDelearMobileNo() {
		return delearMobileNo;
	}
	public void setDelearMobileNo(String delearMobileNo) {
		this.delearMobileNo = delearMobileNo;
	}
	public String getDelearFlag() {
		return delearFlag;
	}
	public void setDelearFlag(String delearFlag) {
		this.delearFlag = delearFlag;
	}
	public String getRegDate() {
		return regDate;
	}
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getClmStatus() {
		return clmStatus;
	}
	public void setClmStatus(String clmStatus) {
		this.clmStatus = clmStatus;
	}
	
}
