package com.jipl.JIPLCLMAPP.model;

public class DocumentUploadRequest {
	private String docName;
	private String docData;
	private String docExtention;
	private String claimNumber;
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public String getDocData() {
		return docData;
	}
	public void setDocData(String docData) {
		this.docData = docData;
	}
	public String getDocExtention() {
		return docExtention;
	}
	public void setDocExtention(String docExtention) {
		this.docExtention = docExtention;
	}
	public String getClaimNumber() {
		return claimNumber;
	}
	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

}
