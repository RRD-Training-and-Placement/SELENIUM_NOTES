package com.jipl.JIPLCLMAPP.model;

import org.springframework.stereotype.Component;

@Component
public class DeleteMultiClaimRequest {
   private String claimNo;
   private String delearFlag;
public String getClaimNo() {
	return claimNo;
}
public void setClaimNo(String claimNo) {
	this.claimNo = claimNo;
}
public String getDelearFlag() {
	return delearFlag;
}
public void setDelearFlag(String delearFlag) {
	this.delearFlag = delearFlag;
}
}
