package com.jipl.JIPLCLMAPP.model;

public class ClaimCloseRequest {
	private String claimNo;
	private String closingRemark;
	public String getClaimNo() {
		return claimNo;
	}
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}
	public String getClosingRemark() {
		return closingRemark;
	}
	public void setClosingRemark(String closingRemark) {
		this.closingRemark = closingRemark;
	}

}
