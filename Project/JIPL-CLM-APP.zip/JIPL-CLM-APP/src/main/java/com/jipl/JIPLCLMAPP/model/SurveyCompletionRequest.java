package com.jipl.JIPLCLMAPP.model;

public class SurveyCompletionRequest {
	private String surveyorId;
	private String surveyorName;
	private String completionDate;
	private String claimId;
	private String remark;
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getSurveyorId() {
		return surveyorId;
	}
	public void setSurveyorId(String surveyorId) {
		this.surveyorId = surveyorId;
	}
	public String getSurveyorName() {
		return surveyorName;
	}
	public void setSurveyorName(String surveyorName) {
		this.surveyorName = surveyorName;
	}
	public String getCompletionDate() {
		return completionDate;
	}
	public void setCompletionDate(String completionDate) {
		this.completionDate = completionDate;
	}
	public String getClaimId() {
		return claimId;
	}
	public void setClaimId(String claimId) {
		this.claimId = claimId;
	}

}
