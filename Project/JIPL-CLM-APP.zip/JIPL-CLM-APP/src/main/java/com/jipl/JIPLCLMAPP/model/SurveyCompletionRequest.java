package com.jipl.JIPLCLMAPP.model;

public class SurveyCompletionRequest {
	private String surveyorId;
	private String claimId;
	private String remark;
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getSurveyorId() {
		return surveyorId;
	}
	public void setSurveyorId(String surveyorId) {
		this.surveyorId = surveyorId;
	}
	public String getClaimId() {
		return claimId;
	}
	public void setClaimId(String claimId) {
		this.claimId = claimId;
	}

}
