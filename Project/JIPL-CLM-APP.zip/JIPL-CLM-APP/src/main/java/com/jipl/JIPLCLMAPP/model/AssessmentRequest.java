package com.jipl.JIPLCLMAPP.model;

public class AssessmentRequest {

}
