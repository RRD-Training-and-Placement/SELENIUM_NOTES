package com.jipl.JIPLCLMAPP.contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.jipl.JIPLCLMAPP.model.ClaimCloseRequest;
import com.jipl.JIPLCLMAPP.model.ClaimCloseResponse;
import com.jipl.JIPLCLMAPP.model.ClmRegDetails;
import com.jipl.JIPLCLMAPP.model.ClmRegRequest;
import com.jipl.JIPLCLMAPP.model.ClmRegResponse;
import com.jipl.JIPLCLMAPP.model.DeleteMultiClaimRequest;
import com.jipl.JIPLCLMAPP.model.DeleteResponse;
import com.jipl.JIPLCLMAPP.model.DocumentUploadRequest;
import com.jipl.JIPLCLMAPP.model.DocumentUploadResponse;
import com.jipl.JIPLCLMAPP.model.SurveyAppoitmentRequest;
import com.jipl.JIPLCLMAPP.model.SurveyAppoitmentResponse;
import com.jipl.JIPLCLMAPP.model.SurveyCompletionRequest;
import com.jipl.JIPLCLMAPP.model.SurveyCompletionResponse;
import com.jipl.JIPLCLMAPP.model.UpdateRequest;
import com.jipl.JIPLCLMAPP.model.UpdateResponse;
import com.jipl.JIPLCLMAPP.service.IClmService;
import com.jipl.JIPLCLMAPP.utility.CommonUtils;

@RestController
public class ClmController {
	@Autowired
	IClmService service;
	
	@PostMapping(path="/clm-register",consumes=MediaType.APPLICATION_JSON_VALUE,
			produces =MediaType.APPLICATION_JSON_VALUE)
	public ClmRegResponse registerClaim(@RequestBody ClmRegRequest regRequest)
	{
		return service.registerClaim(regRequest);
	}
	@GetMapping("/clm-get-single/{Clmno}")
	public ClmRegDetails displaySingleClmDtls(@PathVariable String Clmno)
	{
		return service.getSingleClmDtls(Clmno);
	}
	@PutMapping("/clm-update-single")
	public UpdateResponse updateSingleClmDtls(@RequestBody UpdateRequest request)
	{
		return service.updateSingleClmDtls(request);
	}
	@DeleteMapping("/clm-del-single/{Clmno}")
	public DeleteResponse deleteSingleClmDtls(@PathVariable String Clmno)
	{
		return service.deleteSingleClmDtls(Clmno);
	}
	@DeleteMapping("/clm-del-multi")
	public List<DeleteResponse> deleteMultiClmDtls(@RequestBody List<DeleteMultiClaimRequest> request)
	{
		return service.deleteMultiClmDtls(request);
	}
	@PostMapping(path="/appoint-surveyor",consumes=MediaType.APPLICATION_JSON_VALUE,
			produces =MediaType.APPLICATION_JSON_VALUE)
	public SurveyAppoitmentResponse appointSurveyor(@RequestBody SurveyAppoitmentRequest request)
	{
		
		return service.appointSurveyor(request);
	}
	@PostMapping(path="/survey-compl",consumes=MediaType.APPLICATION_JSON_VALUE,
			produces =MediaType.APPLICATION_JSON_VALUE)
	public SurveyCompletionResponse surveyComplete(@RequestBody SurveyCompletionRequest request)
	{
		
		return service.surveyComplete(request);
	}
	@PostMapping(path="/docUpload",consumes=MediaType.APPLICATION_JSON_VALUE,
			produces =MediaType.APPLICATION_JSON_VALUE)
	public DocumentUploadResponse uplodDocument(@RequestBody DocumentUploadRequest request)
	{
		return service.uplodDocument(request);
	}
	@PutMapping(path="/closeClm",consumes=MediaType.APPLICATION_JSON_VALUE,
			produces =MediaType.APPLICATION_JSON_VALUE)
	public ClaimCloseResponse closeClaim(@RequestBody ClaimCloseRequest request)
	{
		return service.closeClaim(request);
	}
}
