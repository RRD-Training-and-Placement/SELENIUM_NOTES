package com.jipl.JIPLCLMAPP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JiplClmAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(JiplClmAppApplication.class, args);
	}

}
