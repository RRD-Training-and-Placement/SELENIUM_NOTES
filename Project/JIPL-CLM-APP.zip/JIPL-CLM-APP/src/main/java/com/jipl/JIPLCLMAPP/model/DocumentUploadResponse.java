package com.jipl.JIPLCLMAPP.model;

public class DocumentUploadResponse {
	private String ack;
	private String clmno;
	private String message;
	public String getAck() {
		return ack;
	}
	public void setAck(String ack) {
		this.ack = ack;
	}
	public String getClmno() {
		return clmno;
	}
	public void setClmno(String clmno) {
		this.clmno = clmno;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

}
