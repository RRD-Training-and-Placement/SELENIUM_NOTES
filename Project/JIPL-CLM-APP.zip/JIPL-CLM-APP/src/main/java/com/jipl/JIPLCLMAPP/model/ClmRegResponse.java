package com.jipl.JIPLCLMAPP.model;

import org.springframework.stereotype.Component;

@Component
public class ClmRegResponse {
private String ack;// for failure value is 0 and for Sucess value is 1
private String message;
private String clmNo;
private String coverNoteNo;
public String getAck() {
	return ack;
}
public void setAck(String ack) {
	this.ack = ack;
}
public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}
public String getClmNo() {
	return clmNo;
}
public void setClmNo(String clmNo) {
	this.clmNo = clmNo;
}
public String getCoverNoteNo() {
	return coverNoteNo;
}
public void setCoverNoteNo(String coverNoteNo) {
	this.coverNoteNo = coverNoteNo;
}


}
