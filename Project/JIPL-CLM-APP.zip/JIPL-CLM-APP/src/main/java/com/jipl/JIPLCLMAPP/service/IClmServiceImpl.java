package com.jipl.JIPLCLMAPP.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jipl.JIPLCLMAPP.dao.IClmDao;
import com.jipl.JIPLCLMAPP.model.ClaimCloseRequest;
import com.jipl.JIPLCLMAPP.model.ClaimCloseResponse;
import com.jipl.JIPLCLMAPP.model.ClmRegDetails;
import com.jipl.JIPLCLMAPP.model.ClmRegRequest;
import com.jipl.JIPLCLMAPP.model.ClmRegResponse;
import com.jipl.JIPLCLMAPP.model.DeleteMultiClaimRequest;
import com.jipl.JIPLCLMAPP.model.DeleteResponse;
import com.jipl.JIPLCLMAPP.model.DocumentUploadRequest;
import com.jipl.JIPLCLMAPP.model.DocumentUploadResponse;
import com.jipl.JIPLCLMAPP.model.SurveyAppoitmentRequest;
import com.jipl.JIPLCLMAPP.model.SurveyAppoitmentResponse;
import com.jipl.JIPLCLMAPP.model.SurveyCompletionRequest;
import com.jipl.JIPLCLMAPP.model.SurveyCompletionResponse;
import com.jipl.JIPLCLMAPP.model.UpdateRequest;
import com.jipl.JIPLCLMAPP.model.UpdateResponse;
import com.jipl.JIPLCLMAPP.utility.CommonUtils;

@Service
public class IClmServiceImpl implements IClmService {

	@Autowired
	IClmDao dao;

	
	@Override
	public ClmRegResponse registerClaim(ClmRegRequest regRequest) {
		ClmRegResponse response = new ClmRegResponse();
		String coverNoteNo = regRequest.getCoverNoteNo();
		if (coverNoteNo == null || coverNoteNo.isEmpty() || coverNoteNo.length() == 0) {
			response.setAck("0");
			response.setMessage("Cover Note Number Not Provided, hence Claim not Registered");
			response.setClmNo("");
			response.setCoverNoteNo("");
			return response;
		}
		String customerName = regRequest.getCustomerName();
		if (customerName == null || customerName.isEmpty() || customerName.length() == 0) {
			response.setAck("0");
			response.setMessage("Customer name not provided,hence Claim not Registered");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		String placeOfAccident = regRequest.getPlaceOfAccident();
		if (placeOfAccident == null || placeOfAccident.isEmpty() || placeOfAccident.length() == 0) {
			response.setAck("0");
			response.setMessage("Place of Accident not provided,hence Claim not Registered ");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		String vehicalRegNo = regRequest.getVehicalRegNo();
		if (vehicalRegNo == null || vehicalRegNo.isEmpty() || vehicalRegNo.length() == 0) {
			response.setAck("0");
			response.setMessage("Vehical Number not provided,hence Claim not Registered");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		if(CommonUtils.validateRegistrationNumber(vehicalRegNo)==false)
		{
			response.setAck("0");
			response.setMessage("Please Provide Vehical Registration Number in valid Format");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		String licenNo = regRequest.getLicenNo();
		if (licenNo == null || licenNo.isEmpty() || licenNo.length() == 0) {
			response.setAck("0");
			response.setMessage("Licen number not provided,hence Claim not Registered");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		if(CommonUtils.validateLicenNumber(licenNo)==false)
		{
			response.setAck("0");
			response.setMessage("Please provide Licen number in valid Format");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		String dateOfBith = regRequest.getDateOfBith();
		if (dateOfBith == null || dateOfBith.isEmpty() || dateOfBith.length() == 0) {
			response.setAck("0");
			response.setMessage("Date of Birth not provided,hence Claim not Registered");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		if(CommonUtils.validateDateFormate(dateOfBith)==false)
		{
			response.setAck("0");
			response.setMessage("Date of Birth should be in dd-MM-yyyy Format");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		if(CommonUtils.isFutureDate(dateOfBith)==true)
		{
			response.setAck("0");
			response.setMessage("Date of Birth should not future Date");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		String causeOfAccident = regRequest.getCauseOfAccident();
		if (causeOfAccident == null || causeOfAccident.isEmpty() || causeOfAccident.length() == 0) {
			response.setAck("0");
			response.setMessage("Cause of Accident not provided,hence Claim not Registered");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		String accidentDate = regRequest.getAccidentDate();
		if (accidentDate == null || accidentDate.isEmpty() || accidentDate.length() == 0) {

			response.setAck("0");
			response.setMessage("Accident Date not provided,hence Claim not Registered");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		if(CommonUtils.validateDateFormate(accidentDate)==false)
		{
			response.setAck("0");
			response.setMessage("Accident Date should be in dd-MM-yyyy Format");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		if(CommonUtils.isFutureDate(accidentDate)==true)
		{
			response.setAck("0");
			response.setMessage("Accident Date should not be future Date");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		String driveName = regRequest.getDriveName();
		if (driveName == null || driveName.isEmpty() || driveName.length() == 0) {

			response.setAck("0");
			response.setMessage("Drive name not provided,hence Claim not Registered");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		String mobileNo = regRequest.getMobileNo();
		if (mobileNo == null || mobileNo.isEmpty() || mobileNo.length() == 0) {

			response.setAck("0");
			response.setMessage("Customer Mobile number not provided,hence Claim not Registered");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		if(CommonUtils.validateMobileNumber(mobileNo)==false)
		{
			response.setAck("0");
			response.setMessage("Please Provide valid Customer Mobile number ");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		String workshopId = regRequest.getWorkshopId();
		if (workshopId == null || workshopId.isEmpty() || workshopId.length() == 0) {

			response.setAck("0");
			response.setClmNo("");
			response.setMessage("Workshop Id not provided,hence Claim not Registered");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		String workshopCity = regRequest.getWorkshopCity();
		if (workshopCity == null || workshopCity.isEmpty() || workshopCity.length() == 0) {

			response.setAck("0");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			response.setMessage("Workshop city not provided,hence Claim not Registered");
			return response;
		}
		boolean VworkshopId=CommonUtils.validateWorkshpId(workshopId,workshopCity);
		if(VworkshopId==false)
		{
			response.setAck("0");
			response.setClmNo("");
			response.setMessage("Provided Workshop Id is not present,Please configure Workshop Id " +workshopId);
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		
		String delearMobileNo = regRequest.getDelearMobileNo();
		if (delearMobileNo == null || delearMobileNo.isEmpty() || delearMobileNo.length() == 0) {

			response.setAck("0");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			response.setMessage("Delear MobileNo not provided,hence Claim not Registered");
			return response;
		}
		if (delearMobileNo.trim().length() != 10) {

			response.setAck("0");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			response.setMessage("Please provide 10 digit Delear Mobile number");
			return response;
		}
		if(CommonUtils.validateMobileNumber(delearMobileNo)==false)
		{
			response.setAck("0");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			response.setMessage("Please provide valid Delear Mobile number");
			return response;
		}
		String delearClaimId = regRequest.getDelearClaimId();
		if (delearClaimId == null || delearClaimId.isEmpty() || delearClaimId.length() == 0) {

			response.setAck("0");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			response.setMessage("Delear ClaimId not provided,hence Claim not Registered");
			return response;
		}
		String delearFlag = regRequest.getDelearFlag();
		if (delearFlag == null || delearFlag.isEmpty() || delearFlag.length() == 0) {

			response.setAck("0");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			response.setMessage("Delear Flag not provided,hence Claim not Registered");
			return response;
		}
		if (CommonUtils.validateDelearFlag(delearFlag)==false) {

			response.setAck("0");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			response.setMessage("Please provide valid Delear Flag");
			return response;
		}
		return dao.registerClaim(regRequest);
		
	}
	public ClmRegDetails getSingleClmDtls(String clmNo) {
		return dao.getSingleClmDtls(clmNo);
	}
	@Override
	public DeleteResponse deleteSingleClmDtls(String Clmno) {
		
		return dao.deleteSingleClmDtls(Clmno);
	}

	@Override
	public List<DeleteResponse> deleteMultiClmDtls(List<DeleteMultiClaimRequest> request) {
		
		return dao.deleteMultiClmDtls(request);
	}
	@Override
	public UpdateResponse updateSingleClmDtls(UpdateRequest request) {
		String clmno=request.getClmno();
		String delearFlag=request.getDelearFlag();
		String custMobileNo=request.getCustMobileNo();
		String delearMobileNo=request.getDelearMobileNo();
		
		UpdateResponse response=new UpdateResponse();
		
		if (clmno == null || clmno.isEmpty() || clmno.length() == 0) {
			response.setAck("0");
			response.setClmno("");
			response.setMessage("Please provide Claim Number");
			return response;
		}
		if (delearFlag == null || delearFlag.isEmpty() || delearFlag.length() == 0) {

			response.setAck("0");
			response.setClmno("");
			response.setMessage("Please provide Delear Flag");
			return response;
		}
		if (custMobileNo == null || custMobileNo.isEmpty() || custMobileNo.length() == 0) {

			response.setAck("0");
			response.setClmno("");
			response.setMessage("Please provide Customer Mobile Number");
			return response;
		}
		if (custMobileNo.trim().length() !=10) {

			response.setAck("0");
			response.setClmno("");
			response.setMessage("Please provide 10 digit mobile Number");
			return response;
		}
		if (delearMobileNo == null || delearMobileNo.isEmpty() || delearMobileNo.length() == 0) {

			response.setAck("0");
			response.setClmno("");
			response.setMessage("Please provide Delealer Mobile Number");
			return response;
		}
		if (delearMobileNo.trim().length() !=10) {
			response.setAck("0");
			response.setClmno("");
			response.setMessage("Please provide 10 digit Mobile Number");
			return response;
		}
		
		return dao.updateSingleClmDtls(request);
	}
	public SurveyAppoitmentResponse appointSurveyor(SurveyAppoitmentRequest request)
	{
		SurveyAppoitmentResponse response=new SurveyAppoitmentResponse();
		String clainNo=request.getClaimId();
		if(clainNo==null)
		{
			response.setAck("0");
			response.setClmNo("");
			response.setMessage("Please Provide Claim Number");
			return response;
		}
		boolean result=CommonUtils.validateClaimNumber(clainNo);
		if(result==false)
		{
			response.setAck("0");
			response.setClmNo(clainNo);
			response.setMessage("Please Provide Valid Claim Number");
			return response;
		}
		String appDate=request.getAppoitmentDate();
		if(appDate==null)
		{
			response.setAck("0");
			response.setClmNo(request.getClaimId());
			response.setMessage("Please provide Date of Appoitment");
			return response;
		}
		if(CommonUtils.validateDateFormate(appDate)==false)
		{
			response.setAck("0");
			response.setClmNo(request.getClaimId());
			response.setMessage("Please provide Date of Appoitment in valid Format");
			return response;
		}
		
		if(request.getSurveyorName()==null)
		{
			response.setAck("0");
			response.setClmNo(request.getClaimId());
			response.setMessage("Please provide Surveyor Name");
			return response;
		}
		if(request.getSurveyorId()==null)
		{
			response.setAck("0");
			response.setClmNo(request.getClaimId());
			response.setMessage("Please provide Surveyor Id");
			return response;
		}
		return dao.appointSurveyor(request);
	}
	public SurveyCompletionResponse surveyComplete(SurveyCompletionRequest request)
	{
		SurveyCompletionResponse response=new SurveyCompletionResponse();
		if(request.getClaimId()==null)
		{
			response.setAck("0");
			response.setClmNo("");
			response.setMessage("Please Provide Claim Number");
			return response;
		}
		boolean result=CommonUtils.validateClaimNumber(request.getClaimId());
		if(result==false)
		{
			response.setAck("0");
			response.setClmNo(request.getClaimId());
			response.setMessage("Please provide Valid Claim Number");
		}
		String surveyComplDate=request.getCompletionDate();
		if(surveyComplDate==null)
		{
			response.setAck("0");
			response.setClmNo(request.getClaimId());
			response.setMessage("Please provide Date of Completion");
			return response;
		}
		
		if(request.getSurveyorName()==null)
		{
			response.setAck("0");
			response.setClmNo(request.getClaimId());
			response.setMessage("Please provide Surveyor Name");
			return response;
		}
		if(request.getSurveyorId()==null)
		{
			response.setAck("0");
			response.setClmNo(request.getClaimId());
			response.setMessage("Please provide Surveyor Id");
			return response;
		}
		if(request.getRemark()==null)
		{
			response.setAck("0");
			response.setClmNo(request.getClaimId());
			response.setMessage("Please provide Remark");
			return response;
		}
		return dao.surveyComplete(request);
	}
	public DocumentUploadResponse uplodDocument(DocumentUploadRequest request)
	{
		DocumentUploadResponse response=new DocumentUploadResponse();
		if(request.getClaimNumber()==null||request.getClaimNumber().isEmpty()||request.getClaimNumber().length()==0)
		{
				response.setAck("0");
				response.setMessage("Please provide Claim number");
				response.setClmno("");
				return response;
		}
		String claimNumber=request.getClaimNumber();
		boolean vClaimNumber=CommonUtils.validateClaimNumber(claimNumber);
		if(vClaimNumber==false)
		{
			response.setAck("0");
			response.setMessage("Please provide valid Claim number");
			response.setClmno(claimNumber);
			return response;
		}
		if(request.getDocData()==null||request.getDocData().length()==0)
		{
			response.setAck("0");
			response.setMessage("Please provide Document Data");
			response.setClmno(claimNumber);
			return response;
		}
		if(request.getDocExtention()==null||request.getDocExtention().length()==0)
		{
			response.setAck("0");
			response.setMessage("Please provide Document extention");
			response.setClmno(claimNumber);
			return response;
		}
		String vDocExt=request.getDocExtention();
		if(CommonUtils.validateDocExtention(vDocExt)==false)
		{
			response.setAck("0");
			response.setMessage("Please provide Document extention as pdf");
			response.setClmno(claimNumber);
			return response;
		}
		if(request.getDocName()==null||request.getDocName().length()==0)
		{
			response.setAck("0");
			response.setMessage("Please provide Document name");
			response.setClmno(claimNumber);
			return response;
		}
		return dao.uplodDocument(request);
	}
	public ClaimCloseResponse closeClaim(ClaimCloseRequest request)
	{
		ClaimCloseResponse response=new ClaimCloseResponse();
		String vClaimNo=request.getClaimNo();
		if(vClaimNo==null||vClaimNo.length()==0 ||vClaimNo.isEmpty())
		{
			response.setAck("0");
			response.setClmNo("");
			response.setMessage("Please provide Claim number");
		}
		boolean validClaim=CommonUtils.validateClaimNumber(vClaimNo);
		if(validClaim==false)
		{
			response.setAck("0");
			response.setClmNo(vClaimNo);
			response.setMessage("Please provide Valid claim number");
		}
		if(request.getClosingRemark()==null||request.getClosingRemark().length()==0)
		{
			response.setAck("0");
			response.setClmNo(vClaimNo);
			response.setMessage("Please provide Claim Closing Remark");
		}
		return dao.closeClaim(request);
	}
}
