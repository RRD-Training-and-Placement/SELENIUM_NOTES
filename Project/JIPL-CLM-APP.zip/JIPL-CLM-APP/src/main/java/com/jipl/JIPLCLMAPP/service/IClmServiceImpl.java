package com.jipl.JIPLCLMAPP.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jipl.JIPLCLMAPP.dao.IClmDao;
import com.jipl.JIPLCLMAPP.model.ClaimCloseRequest;
import com.jipl.JIPLCLMAPP.model.ClaimCloseResponse;
import com.jipl.JIPLCLMAPP.model.ClmRegDetails;
import com.jipl.JIPLCLMAPP.model.ClmRegRequest;
import com.jipl.JIPLCLMAPP.model.ClmRegResponse;
import com.jipl.JIPLCLMAPP.model.DeleteMultiClaimRequest;
import com.jipl.JIPLCLMAPP.model.DeleteResponse;
import com.jipl.JIPLCLMAPP.model.DocumentUploadRequest;
import com.jipl.JIPLCLMAPP.model.DocumentUploadResponse;
import com.jipl.JIPLCLMAPP.model.SurveyAppoitmentRequest;
import com.jipl.JIPLCLMAPP.model.SurveyAppoitmentResponse;
import com.jipl.JIPLCLMAPP.model.SurveyCompletionRequest;
import com.jipl.JIPLCLMAPP.model.SurveyCompletionResponse;
import com.jipl.JIPLCLMAPP.model.UpdateRequest;
import com.jipl.JIPLCLMAPP.model.UpdateResponse;
import com.jipl.JIPLCLMAPP.utility.CommonUtils;

@Service
public class IClmServiceImpl implements IClmService {

	@Autowired
	IClmDao dao;

	
	@Override
	public ClmRegResponse registerClaim(ClmRegRequest regRequest) {
		ClmRegResponse response = new ClmRegResponse();
		String coverNoteNo = regRequest.getCoverNoteNo();
		if (coverNoteNo == null || coverNoteNo.isEmpty() || coverNoteNo.length() == 0) {
			response.setAck("0");
			response.setMessage("Cover Note Number Not Provided, hence Claim not Registered");
			response.setClmNo("");
			response.setCoverNoteNo("");
			return response;
		}
		String customerName = regRequest.getCustomerName();
		if (customerName == null || customerName.isEmpty() || customerName.length() == 0) {
			response.setAck("0");
			response.setMessage("Customer name not provided,hence Claim not Registered");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		String placeOfAccident = regRequest.getPlaceOfAccident();
		if (placeOfAccident == null || placeOfAccident.isEmpty() || placeOfAccident.length() == 0) {
			response.setAck("0");
			response.setMessage("Place of Accident not provided,hence Claim not Registered ");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		String vehicalRegNo = regRequest.getVehicalRegNo();
		if (vehicalRegNo == null || vehicalRegNo.isEmpty() || vehicalRegNo.length() == 0) {
			response.setAck("0");
			response.setMessage("Vehical Number not provided,hence Claim not Registered");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		if(CommonUtils.validateRegistrationNumber(vehicalRegNo)==false)
		{
			response.setAck("0");
			response.setMessage("Please Provide Vehical Registration Number in valid Format");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		String licenNo = regRequest.getLicenNo();
		if (licenNo == null || licenNo.isEmpty() || licenNo.length() == 0) {
			response.setAck("0");
			response.setMessage("Licen number not provided,hence Claim not Registered");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		if(CommonUtils.validateLicenNumber(licenNo)==false)
		{
			response.setAck("0");
			response.setMessage("Please provide Licen number in valid Format");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		String dateOfBith = regRequest.getDateOfBith();
		if (dateOfBith == null || dateOfBith.isEmpty() || dateOfBith.length() == 0) {
			response.setAck("0");
			response.setMessage("Date of Birth not provided,hence Claim not Registered");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		if(CommonUtils.validateDateFormate(dateOfBith)==false)
		{
			response.setAck("0");
			response.setMessage("Date of Birth should be in yyyy-MM-dd Format");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		if(CommonUtils.isFutureDate(dateOfBith)==true)
		{
			response.setAck("0");
			response.setMessage("Date of Birth should not future Date");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		if(CommonUtils.calcuateAge(dateOfBith)<21)
		{
			response.setAck("0");
			response.setMessage("Not valid Date of Birth as Age is less than 21 years");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		String causeOfAccident = regRequest.getCauseOfAccident();
		if (causeOfAccident == null || causeOfAccident.isEmpty() || causeOfAccident.length() == 0) {
			response.setAck("0");
			response.setMessage("Cause of Accident not provided,hence Claim not Registered");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		String accidentDate = regRequest.getAccidentDate();
		if (accidentDate == null || accidentDate.isEmpty() || accidentDate.length() == 0) {

			response.setAck("0");
			response.setMessage("Accident Date not provided,hence Claim not Registered");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		if(CommonUtils.validateDateFormate(accidentDate)==false)
		{
			response.setAck("0");
			response.setMessage("Accident Date should be in yyyy-MM-dd Format");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		if(CommonUtils.isFutureDate(accidentDate)==true)
		{
			response.setAck("0");
			response.setMessage("Accident Date should not be future Date");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		String driveName = regRequest.getDriveName();
		if (driveName == null || driveName.isEmpty() || driveName.length() == 0) {

			response.setAck("0");
			response.setMessage("Drive name not provided,hence Claim not Registered");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		String mobileNo = regRequest.getMobileNo();
		if (mobileNo == null || mobileNo.isEmpty() || mobileNo.length() == 0 ) {

			response.setAck("0");
			response.setMessage("Customer Mobile number not provided,hence Claim not Registered");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		if(mobileNo.trim().length()!=10)
		{
			response.setAck("0");
			response.setMessage("Customer Mobile number is not 10 digit,hence Claim not Registered");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		if(CommonUtils.validateMobileNumber(mobileNo)==false)
		{
			response.setAck("0");
			response.setMessage("Please Provide valid Customer Mobile number ");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		String workshopId = regRequest.getWorkshopId();
		if (workshopId == null || workshopId.isEmpty() || workshopId.length() == 0) {

			response.setAck("0");
			response.setClmNo("");
			response.setMessage("Workshop Id not provided,hence Claim not Registered");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		String delearFlag = regRequest.getDelearFlag();
		if (delearFlag == null || delearFlag.isEmpty() || delearFlag.length() == 0) {

			response.setAck("0");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			response.setMessage("Delear Flag not provided,hence Claim not Registered");
			return response;
		}
		if (CommonUtils.validateDelearFlag(delearFlag)==false) {

			response.setAck("0");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			response.setMessage("Please provide valid Delear Flag");
			return response;
		}
		String workshopCity = regRequest.getWorkshopCity();
		if (workshopCity == null || workshopCity.isEmpty() || workshopCity.length() == 0) {

			response.setAck("0");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			response.setMessage("Workshop city not provided,hence Claim not Registered");
			return response;
		}
		String workshopName=CommonUtils.validateWorkshpId(workshopId,delearFlag.toUpperCase(),workshopCity);
		if(workshopName==null)
		{
			response.setAck("0");
			response.setClmNo("");
			response.setMessage("Provided Workshop Id is not present,Please configure Workshop Id " +workshopId);
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			return response;
		}
		String delearMobileNo = regRequest.getDelearMobileNo();
		if (delearMobileNo == null || delearMobileNo.isEmpty() || delearMobileNo.length() == 0) {

			response.setAck("0");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			response.setMessage("Delear MobileNo not provided,hence Claim not Registered");
			return response;
		}
		if(delearMobileNo.trim().length()!=10)
		{
			response.setAck("0");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			response.setMessage("Delear MobileNo is not 10 digit,hence Claim not Registered");
			return response;
		}
		if(CommonUtils.validateMobileNumber(delearMobileNo)==false)
		{
			response.setAck("0");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			response.setMessage("Please provide valid Delear Mobile number");
			return response;
		}
		String delearClaimId = regRequest.getDelearClaimId();
		if (delearClaimId == null || delearClaimId.isEmpty() || delearClaimId.length() == 0) {

			response.setAck("0");
			response.setClmNo("");
			response.setCoverNoteNo(coverNoteNo);
			response.setMessage("Delear ClaimId not provided,hence Claim not Registered");
			return response;
		}
		
		return dao.registerClaim(regRequest);
		
	}
	@Override
	public UpdateResponse updateSingleClmDtls(UpdateRequest request) {
		String clmno=request.getClmno();
		String delearFlag=request.getDelearFlag();
		String custMobileNo=request.getCustMobileNo();
		String delearMobileNo=request.getDelearMobileNo();
		
		UpdateResponse response=new UpdateResponse();
		
		if (clmno == null || clmno.isEmpty() || clmno.length() == 0) {
			response.setAck("0");
			response.setClmno("");
			response.setMessage("Please provide Claim Number");
			return response;
		}
		if (delearFlag == null || delearFlag.isEmpty() || delearFlag.length() == 0) {

			response.setAck("0");
			response.setClmno("");
			response.setMessage("Please provide Delear Flag");
			return response;
		}
		if(CommonUtils.validateDelearFlag(delearFlag)==false)
		{
			response.setAck("0");
			response.setClmno(clmno);
			response.setMessage("Please provide Valid Delear Flag");
			return response;
		}
		if(CommonUtils.validateClaimNumberWithFlag(clmno,delearFlag)==false)
		{
			response.setAck("0");
			response.setClmno(clmno);
			response.setMessage("Provided Claim Number Does not Exist!!");
			return response;
		}
		if (custMobileNo == null || custMobileNo.isEmpty() || custMobileNo.length() == 0) {

			response.setAck("0");
			response.setClmno(clmno);
			response.setMessage("Please Provide Customer Mobile Number");
			return response;
		}
		if (custMobileNo.trim().length() !=10) {

			response.setAck("0");
			response.setClmno(clmno);
			response.setMessage("Please Provide 10 digit Customer mobile Number");
			return response;
		}
		if(CommonUtils.validateMobileNumber(custMobileNo)==false)
		{
			response.setAck("0");
			response.setClmno(clmno);
			response.setMessage("Please Provide Valid Customer mobile Number");
			return response;
		}
		if (delearMobileNo == null || delearMobileNo.isEmpty() || delearMobileNo.length() == 0) {

			response.setAck("0");
			response.setClmno(clmno);
			response.setMessage("Please provide Delealer Mobile Number");
			return response;
		}
		if (delearMobileNo.trim().length() !=10) {
			response.setAck("0");
			response.setClmno(clmno);
			response.setMessage("Please provide 10 digit Delealer Mobile Number");
			return response;
		}
		if(CommonUtils.validateMobileNumber(delearMobileNo)==false)
		{
			response.setAck("0");
			response.setClmno(clmno);
			response.setMessage("Please provide valid Delealer Mobile Number");
			return response;
		}
		return dao.updateSingleClmDtls(request);
	}
	public ClmRegDetails getSingleClmDtls(String clmNo) {
		return dao.getSingleClmDtls(clmNo);
	}
	@Override
	public DeleteResponse deleteSingleClmDtls(String Clmno) {
		
		return dao.deleteSingleClmDtls(Clmno);
	}

	@Override
	public List<DeleteResponse> deleteMultiClmDtls(List<DeleteMultiClaimRequest> request) {
		List<DeleteResponse> listResponse=new ArrayList<DeleteResponse>();
		DeleteResponse del=null;
		for (DeleteMultiClaimRequest deleteMultiClaimRequest : request) {
			String clmNo=deleteMultiClaimRequest.getClaimNo();
			String flag=deleteMultiClaimRequest.getDelearFlag();
			if(clmNo==null||clmNo.isEmpty()||clmNo.length()==0)
			{
				del=new DeleteResponse();
				del.setAck("0");
				del.setClmNo(clmNo);
				del.setMessage("Please Provide Claim Number");
				return listResponse;
			}
			if(flag==null||flag.isEmpty()||flag.length()==0)
			{
				del=new DeleteResponse();
				del.setAck("0");
				del.setClmNo(clmNo);
				del.setMessage("Please Provide Delear Flag");
				return listResponse;
			}
			if(CommonUtils.validateDelearFlag(flag)==false)
			{
				del=new DeleteResponse();
				del.setAck("0");
				del.setClmNo(clmNo);
				del.setMessage("Please Provide valid Delear Flag");
				return listResponse;
			}
			
		}
		return dao.deleteMultiClmDtls(request);
	}
	
	public SurveyAppoitmentResponse appointSurveyor(SurveyAppoitmentRequest request)
	{
		SurveyAppoitmentResponse response=new SurveyAppoitmentResponse();
		String clainNo=request.getClaimId();
		if(clainNo==null ||clainNo.isEmpty()||clainNo.length()==0)
		{
			response.setAck("0");
			response.setClmNo("");
			response.setMessage("Please Provide Claim Number");
			return response;
		}
		if(CommonUtils.validateClaimNumber(clainNo)==false)
		{
			response.setAck("0");
			response.setClmNo(clainNo);
			response.setMessage("Please Provide Valid Claim Number");
			return response;
		}
		String sid=request.getSurveyorId();
		if(sid==null||sid.isEmpty()||sid.length()==0)
		{
			response.setAck("0");
			response.setClmNo(request.getClaimId());
			response.setMessage("Please provide Surveyor Id");
			return response;
		}
		String sname=request.getSurveyorName();
		if(sname==null||sname.isEmpty()||sname.length()==0)
		{
			response.setAck("0");
			response.setClmNo(request.getClaimId());
			response.setMessage("Please provide Surveyor Name");
			return response;
		}
		
		if(CommonUtils.validateSurveyDtls(sid, sname)==false)
		{
			response.setAck("0");
			response.setClmNo(clainNo);
			response.setMessage("Surveyor ID and Name not matching,Please Configure Surveyor Id and name");
			return response;
		}
		String clmStatus=CommonUtils.getClaimStatusFromClaimNuber(clainNo);
		if(clmStatus.equalsIgnoreCase("Open"))
		{
			return dao.appointSurveyor(request);
		}
		else 
		{
			response.setAck("0");
			response.setClmNo(clainNo);
			response.setMessage("Surveyor is already Appointed for given Claim number and Current Status is "+clmStatus);
			return response;
		}
	}
	public SurveyCompletionResponse surveyComplete(SurveyCompletionRequest request)
	{
		SurveyCompletionResponse response=new SurveyCompletionResponse();
		String clmNo=request.getClaimId();
		if(clmNo==null||clmNo.isEmpty()||clmNo.length()==0)
		{
			response.setAck("0");
			response.setClmNo("");
			response.setMessage("Please Provide Claim Number");
			return response;
		}
		boolean result=CommonUtils.validateClaimNumber(clmNo);
		if(result==false)
		{
			response.setAck("0");
			response.setClmNo(request.getClaimId());
			response.setMessage("Please provide Valid Claim Number");
		}
		String surveyorId=request.getSurveyorId();
		if(surveyorId==null||surveyorId.isEmpty()||surveyorId.length()==0)
		{
			response.setAck("0");
			response.setClmNo(request.getClaimId());
			response.setMessage("Please provide Surveyor Id");
			return response;
		}
		String remark=request.getRemark();
		if(remark==null||remark.isEmpty()||remark.length()==0)
		{
			response.setAck("0");
			response.setClmNo(request.getClaimId());
			response.setMessage("Please provide Survey Completion Remark");
			return response;
		}
		String clmStatus=CommonUtils.isSurveyAppointed(surveyorId,clmNo);
		if(clmStatus==null)
		{
			response.setAck("0");
			response.setClmNo(request.getClaimId());
			response.setMessage("Please provide Valid Surveyor ID");
			return response;
		}
		if(clmStatus.equalsIgnoreCase("Open"))
		{
			response.setAck("0");
			response.setClmNo(request.getClaimId());
			response.setMessage("Surveyor is not Appointed,Please Surveyor First");
			return response;
		}
		if(clmStatus.equalsIgnoreCase("SC"))
		{
			response.setAck("0");
			response.setClmNo(request.getClaimId());
			response.setMessage("Survey Completion is Already Done");
			return response;
		}
		if(clmStatus.equalsIgnoreCase("SA"))
		{
			return dao.surveyComplete(request);
		}
		else
		{
			response.setAck("0");
			response.setClmNo(request.getClaimId());
			response.setMessage("Survey Completion is Already Done Current Status is "+clmStatus);
			return response;
		}
		
		
	}
	public DocumentUploadResponse uplodDocument(DocumentUploadRequest request)
	{
		DocumentUploadResponse response=new DocumentUploadResponse();
		String clmNo=request.getClaimNumber();
		if(clmNo==null||clmNo.isEmpty()||clmNo.length()==0)
		{
				response.setAck("0");
				response.setMessage("Please provide Claim number");
				response.setClmno("");
				return response;
		}
		boolean vClaimNumber=CommonUtils.validateClaimNumber(clmNo);
		if(vClaimNumber==false)
		{
			response.setAck("0");
			response.setMessage("Please provide valid Claim number");
			response.setClmno(clmNo);
			return response;
		}
		if(request.getDocData()==null||request.getDocData().length()==0)
		{
			response.setAck("0");
			response.setMessage("Please provide Document Data");
			response.setClmno(clmNo);
			return response;
		}
		if(request.getDocExtention()==null||request.getDocExtention().length()==0)
		{
			response.setAck("0");
			response.setMessage("Please provide Document extention");
			response.setClmno(clmNo);
			return response;
		}
		String vDocExt=request.getDocExtention();
		if(CommonUtils.validateDocExtention(vDocExt)==false)
		{
			response.setAck("0");
			response.setMessage("Please provide Document extention as pdf");
			response.setClmno(clmNo);
			return response;
		}
		if(request.getDocName()==null||request.getDocName().length()==0)
		{
			response.setAck("0");
			response.setMessage("Please provide Document name");
			response.setClmno(clmNo);
			return response;
		}
		String clmStatus=CommonUtils.getClaimStatusFromClaimNuber(clmNo);
		if(clmStatus==null)
		{
			response.setAck("0");
			response.setMessage("Provided Claim Number Not Exist");
			response.setClmno(clmNo);
			return response;
		}
		if(clmStatus.equalsIgnoreCase("SA"))
		{
			return dao.uplodDocument(request);
		}
		if(clmStatus.equalsIgnoreCase("DU"))
		{
			response.setAck("0");
			response.setMessage("Document is Already Uploaded against Given Claim");
			response.setClmno(clmNo);
			return response;
		}
		else
		{
			response.setAck("0");
			response.setMessage("Can't Upload Document, Claim Status is "+clmStatus);
			response.setClmno(clmNo);
			return response;
		}
	}
	public ClaimCloseResponse closeClaim(ClaimCloseRequest request)
	{
		ClaimCloseResponse response=new ClaimCloseResponse();
		String vClaimNo=request.getClaimNo();
		if(vClaimNo==null||vClaimNo.length()==0 ||vClaimNo.isEmpty())
		{
			response.setAck("0");
			response.setClmNo("");
			response.setMessage("Please provide Claim number");
			return response;
		}
		String clmStatus=CommonUtils.getClaimStatusFromClaimNuber(vClaimNo);
		if(clmStatus==null)
		{
			response.setAck("0");
			response.setClmNo(vClaimNo);
			response.setMessage("Please provide Valid claim number");
			return response;
		}
		if(request.getClosingRemark()==null||request.getClosingRemark().length()==0)
		{
			response.setAck("0");
			response.setClmNo(vClaimNo);
			response.setMessage("Please provide Claim Closing Remark");
			return response;
		}
		return dao.closeClaim(request);
	}
}
